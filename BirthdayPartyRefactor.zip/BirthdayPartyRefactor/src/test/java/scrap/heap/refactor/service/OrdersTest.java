package scrap.heap.refactor.service;

import org.junit.Assert;
import org.junit.Test;

/**
 * Test class to unit test OrdersImpl
 */
public class OrdersTest {


    public OrdersImpl orders = new OrdersImpl();

    @Test
    public void testOrder() {

        orders.order("red", "mylar", "4", "chocolate", "chocolate", "circle", "large", "brown" );
        Assert.assertEquals("Balloons ordered; red, mylar, 4","Balloons ordered; red, mylar, 4");
        Assert.assertEquals("cake ordered; chocolate, chocolate, circle, large, brown", "cake ordered; chocolate, chocolate, circle, large, brown");
    }
}
