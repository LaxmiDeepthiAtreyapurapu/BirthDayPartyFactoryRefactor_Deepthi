package scrap.heap.refactor.service;

public class OrdersImpl implements Orders{

    /**
     * Method to order balloons
     * @param balloonColor
     * @param material
     * @param number
     */
    public void orderBalloons(String balloonColor, String material, String number){

        //for the purposes of this exercise, pretend this method works and adds balloons to the order
        System.out.println("Balloons ordered; " + balloonColor + ", " + material  + ", " + number);

    }

    /**
     * Method to order cake
     * @param flavor
     * @param frostingFlavor
     * @param shape
     * @param size
     * @param cakeColor
     */
    public void orderCake(String flavor, String frostingFlavor, String shape, String size, String cakeColor){

        //for the purposes of this exercise, pretend that this method adds a cake to the order
        System.out.println("cake ordered; " + flavor + ", " + frostingFlavor  + ", " + shape + ", " + size + ", " + cakeColor);

    }

    /**
     * Method to order
     * @param balloonColor
     * @param material
     * @param number
     * @param flavor
     * @param frostingFlavor
     * @param shape
     * @param size
     * @param cakeColor
     */
    public void order(String balloonColor, String material, String number, String flavor, String frostingFlavor, String shape, String size, String cakeColor){

        orderBalloons(balloonColor, material, number);

        orderCake(frostingFlavor, flavor, shape, size, cakeColor);
    }

}
