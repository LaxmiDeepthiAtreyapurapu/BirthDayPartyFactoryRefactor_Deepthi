package scrap.heap.refactor;

import scrap.heap.refactor.service.OrdersImpl;

public class App {

    private static OrdersImpl orders;

    public String getGreeting() {
        return "Hello world.";
    }

    public static void main(String[] args) {

       //Place birthday party orders
        orders.order("red", "mylar", "4", "chocolate", "chocolate", "circle", "large", "brown" );
        orders.order("blue", "latex", "7", "Vanilla", "chocelate", "square", "med", "brown" );
        orders.order("yellow", "mylar", "4", "vanilla", "vanilla", "square", "small", "yellow" );
    }

}
