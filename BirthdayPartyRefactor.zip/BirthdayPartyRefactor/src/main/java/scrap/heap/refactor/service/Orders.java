package scrap.heap.refactor.service;

public interface Orders {
   public void orderBalloons(String balloonColor, String material, String number);
   public void orderCake(String flavor, String frostingFlavor, String shape, String size, String cakeColor);
}
